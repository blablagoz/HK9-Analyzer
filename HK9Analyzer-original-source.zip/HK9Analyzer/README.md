# HK9 Analyzer v0.1.0

Samsung S24 Ultra / Android 12+ cihazlarda HK9 Pro+ dahil BLE saatlerin **salt okunur GATT keşfi** için Android uygulaması.

## Kurulum / APK üretimi
1. Android Studio (JDK 17, Android SDK 35) ile `HK9Analyzer` klasörünü açın.
2. Gradle senkronizasyonunu bekleyin (Android Gradle Plugin 8.7.3 / Kotlin 2.0.21; ilk kurulumda internet gerekir).
3. **Build > Build APK(s)** seçin. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` altında çıkar.
4. APK'yı S24 Ultra'ya kurun. Bluetooth / Yakındaki cihazlar izni verin.
5. Wearfit Pro saati meşgul ediyorsa uygulamanın bağlantısını geçici kesin. Saatin Bluetooth'ta erişilebilir olduğundan emin olun.
6. **Bluetooth cihazlarını tara** düğmesine basın; saatin adına veya saat ekranındaki MAC'e göre seçin.
7. GATT keşfinden sonra **JSON raporunu kaydet** düğmesine dokunun.

## Neleri yapar?
- BLE reklamlarını tarar, ad/adres/RSSI gösterir.
- Seçilen cihaza GATT bağlantısı kurar.
- Servisleri, karakteristik UUID'lerini, özelliklerini ve tanımlayıcı UUID'lerini kaydeder.
- Yalnızca READ işaretli karakteristikleri sırayla okumayı dener; sonuçları hex olarak kaydeder.
- Android belge seçicisi ile yerel JSON dışa aktarır.

## Neleri yapmaz?
- Firmware/OTA yüklemez; karakteristiklere yazmaz; notification aboneliği yapmaz; telefonun Wearfit Pro uygulamasının trafiğini izlemez.
- Wearfit Pro üreticisine özel protokolü bu ilk sürümde otomatik çözmez.
- Bazı servisler eşleştirme veya özel yetkilendirme isteyebilir; READ komutu hata kodu döndürebilir.
- `neverForLocation` Bluetooth tarama bayrağı bazı beacon reklamlarını filtreleyebilir.

## Gizlilik
Bluetooth MAC adresleri ve okunabilir karakteristik verileri JSON dosyasında bulunabilir. Bu raporu herkese açık platformlarda paylaşmayın. Uygulama internet izni istemez; rapor otomatik gönderilmez.

## Not
Bu çalışma **kaynak kod projesidir**. Bu ortamda Android SDK/Gradle kurulumu bulunmadığından APK derlemesi ve cihaz testi yapılmamıştır. Test sırasında tespit edilen problemler giderilmelidir.

## GitHub Actions ile APK oluşturma
Projeyi GitHub deposunun köküne yükleyin. **Actions > Build HK9 Analyzer APK > Run workflow** işlemini başlatın. Başarılı derlemeden sonra sayfanın **Artifacts** bölümündeki `hk9-analyzer-debug-apk` dosyasından APK'yı indirin. Bu yöntemin çalışması için GitHub Actions'ın depoda etkin olması gerekir. Derleme doğrulanana kadar olası uyumluluk hataları giderilmelidir.
