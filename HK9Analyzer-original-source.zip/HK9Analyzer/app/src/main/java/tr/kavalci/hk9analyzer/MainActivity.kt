package tr.kavalci.hk9analyzer

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.graphics.Typeface
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Diagnostic only. This app does not write GATT characteristics, change firmware or send OTA. */
@Suppress("DEPRECATION")
class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var adapter: BluetoothAdapter
    private lateinit var status: TextView
    private lateinit var resultsContainer: LinearLayout
    private lateinit var dump: TextView
    private lateinit var scanButton: Button
    private lateinit var exportButton: Button
    private var scannerCallback: ScanCallback? = null
    private var gatt: BluetoothGatt? = null
    private var chosen: BluetoothDevice? = null
    private val discovered = linkedMapOf<String, BluetoothDevice>()
    private val report = JSONObject()
    private val serviceJson = JSONArray()
    private val readQueue = ArrayDeque<BluetoothGattCharacteristic>()
    private var pendingRead: BluetoothGattCharacteristic? = null
    private val exportRequest = 301
    private val permissionRequest = 101
    private val scanTimeout = Runnable { stopScan() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        adapter = manager.adapter
        report.put("app", "HK9 Analyzer 0.1.0")
        report.put("export_time", "")
        report.put("read_only", true)
        report.put("phone_model", "${Build.MANUFACTURER} ${Build.MODEL}")
        report.put("android_version", Build.VERSION.RELEASE)
        report.put("services", serviceJson)

        val scroll = ScrollView(this)
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(34, 32, 34, 36) }
        scroll.addView(column)
        fun txt(value: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
            text = value; textSize = size; setPadding(0, 0, 0, 14); if (bold) setTypeface(null, Typeface.BOLD)
        }
        column.addView(txt("HK9 Analyzer", 25f, true))
        column.addView(txt("Salt okunur BLE tanılama • HK9 Pro+ / Wearfit Pro", 14f))
        status = txt("Hazır. Wearfit Pro bağlantısı aktifse taramadan önce uygulamayı kapatabilirsin.", 14f)
        column.addView(status)
        scanButton = Button(this).apply { text = "1 • Bluetooth cihazlarını tara"; setOnClickListener { ensurePermissionsAndScan() } }
        column.addView(scanButton)
        val stopButton = Button(this).apply { text = "Taramayı durdur"; setOnClickListener { stopScan() } }
        column.addView(stopButton)
        resultsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(resultsContainer)
        column.addView(txt("GATT servisleri ve okuma sonuçları", 18f, true))
        dump = txt("Henüz bir cihaz seçilmedi.", 12f).apply { typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }
        column.addView(dump)
        exportButton = Button(this).apply { text = "2 • JSON raporunu kaydet"; isEnabled = false; setOnClickListener { exportReport() } }
        column.addView(exportButton)
        column.addView(txt("Güvenlik: Uygulama BLE yazma, eşleştirme kaldırma veya firmware yükleme işlemi yapmaz. Raporu yalnızca güvenilir kişilerle paylaş; cihaz adresi içerebilir.", 12f))
        setContentView(scroll)
    }

    private fun hasPermissions(): Boolean = if (Build.VERSION.SDK_INT >= 31) {
        checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissionsAndScan() {
        if (!hasPermissions()) {
            val perms = if (Build.VERSION.SDK_INT >= 31)
                arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            requestPermissions(perms, permissionRequest)
            return
        }
        scan()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            if (hasPermissions()) scan() else status.text = "Bluetooth izinleri gerekiyor. Android Ayarlar > Uygulamalar > HK9 Analyzer > İzinler."
        }
    }

    private fun scan() {
        if (!adapter.isEnabled) {
            status.text = "Bluetooth kapalı. Telefonun Bluetooth'unu açıp yeniden dene."
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }
        stopScan()
        discovered.clear(); resultsContainer.removeAllViews()
        status.text = "15 saniye BLE taraması yapılıyor… Saat yakınında olsun."
        val scanner = adapter.bluetoothLeScanner ?: run { status.text = "BLE tarayıcı bulunamadı."; return }
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) { handleResult(result) }
            override fun onBatchScanResults(results: MutableList<ScanResult>) { results.forEach { handleResult(it) } }
            override fun onScanFailed(errorCode: Int) { status.text = "Tarama hatası: $errorCode"; scannerCallback = null }
        }
        scannerCallback = callback
        try { scanner.startScan(callback); handler.postDelayed(scanTimeout, 15000) }
        catch (e: SecurityException) { status.text = "Bluetooth izni hatası: ${e.message}" }
    }

    private fun handleResult(result: ScanResult) {
        val device = result.device
        val address = device.address
        if (discovered.containsKey(address)) return
        discovered[address] = device
        val name = result.scanRecord?.deviceName ?: device.name ?: "İsimsiz BLE cihazı"
        val button = Button(this).apply {
            isAllCaps = false
            text = "$name\n$address  •  RSSI ${result.rssi} dBm\nBağlan ve servisleri oku"
            setOnClickListener { connect(device, name) }
        }
        resultsContainer.addView(button)
        status.text = "${discovered.size} BLE cihazı bulundu. HK9 Pro+ / HK One veya MAC adresini kontrol et."
    }

    private fun stopScan() {
        handler.removeCallbacks(scanTimeout)
        val callback = scannerCallback ?: return
        scannerCallback = null
        try { adapter.bluetoothLeScanner?.stopScan(callback) } catch (_: Exception) { }
    }

    private fun connect(device: BluetoothDevice, displayedName: String) {
        stopScan(); closeGatt()
        chosen = device
        serviceJsonClear()
        report.put("device", JSONObject().put("name", displayedName).put("address", device.address))
        dump.text = "Bağlanılıyor…"
        status.text = "${device.address} cihazına GATT bağlantısı kuruluyor."
        try { gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE) }
        catch (e: Exception) { status.text = "Bağlantı hatası: ${e.message}" }
    }

    private fun serviceJsonClear() { while (serviceJson.length() > 0) serviceJson.remove(serviceJson.length() - 1); readQueue.clear(); pendingRead = null }
    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            runOnUiThread {
                if (g !== gatt) return@runOnUiThread
                if (statusCode == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                    status.text = "Bağlandı. Servisler keşfediliyor…"
                    try { g.discoverServices() } catch (e: Exception) { status.text = "Servis keşfi hatası: ${e.message}" }
                } else {
                    status.text = "Bağlantı kesildi (kod $statusCode). Wearfit Pro bağlantısını geçici kapatıp tekrar deneyebilirsin."
                    exportButton.isEnabled = serviceJson.length() > 0
                    closeGatt()
                }
            }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            runOnUiThread {
                if (g !== gatt) return@runOnUiThread
                if (statusCode != BluetoothGatt.GATT_SUCCESS) { status.text = "GATT keşfi başarısız: $statusCode"; return@runOnUiThread }
                val lines = StringBuilder()
                g.services.forEach { s ->
                    val chars = JSONArray()
                    lines.append("SERVICE ${s.uuid}\n")
                    s.characteristics.forEach { c ->
                        val flags = mutableListOf<String>()
                        if (c.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) flags.add("READ")
                        if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) flags.add("WRITE")
                        if (c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) flags.add("NOTIFY")
                        if (c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) flags.add("INDICATE")
                        chars.put(JSONObject().put("uuid", c.uuid.toString()).put("properties", flags.joinToString(","))
                            .put("descriptors", JSONArray(c.descriptors.map { it.uuid.toString() })))
                        lines.append("  ${c.uuid} [${flags.joinToString()}]\n")
                        if ("READ" in flags) readQueue.addLast(c)
                    }
                    serviceJson.put(JSONObject().put("uuid", s.uuid.toString()).put("characteristics", chars))
                }
                dump.text = lines.toString()
                exportButton.isEnabled = true
                status.text = "${g.services.size} servis keşfedildi; okunabilir karakteristikler sırayla okunuyor…"
                readNext(g)
            }
        }
        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, statusCode: Int) {
            runOnUiThread { completeRead(g, characteristic, value, statusCode) }
        }
        @Deprecated("Legacy callback for Android versions before API 33")
        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            if (Build.VERSION.SDK_INT < 33) runOnUiThread { completeRead(g, characteristic, characteristic.value ?: byteArrayOf(), statusCode) }
        }
    }

    private fun completeRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, bytes: ByteArray, statusCode: Int) {
        if (g !== gatt || characteristic !== pendingRead) return
        serviceJson.forEachObject { service ->
            if (service.optString("uuid") == characteristic.service?.uuid.toString()) {
                service.getJSONArray("characteristics").forEachObject { item ->
                    if (item.optString("uuid") == characteristic.uuid.toString()) {
                        item.put("read_status", statusCode)
                        if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                            item.put("value_hex", bytes.joinToString("") { "%02X".format(it.toInt() and 0xff) })
                            dump.append("\nREAD ${characteristic.uuid}: ${bytes.size} bayt")
                        }
                    }
                }
            }
        }
        pendingRead = null
        readNext(g)
    }

    private fun readNext(g: BluetoothGatt) {
        if (g !== gatt) return
        while (readQueue.isNotEmpty()) {
            val c = readQueue.removeFirst()
            pendingRead = c
            val ok = try { g.readCharacteristic(c) } catch (_: Exception) { false }
            if (ok) return
            pendingRead = null
        }
        status.text = "Analiz tamamlandı. JSON raporunu kaydedebilirsin."
        exportButton.isEnabled = true
    }

    private fun JSONArray.forEachObject(action: (JSONObject) -> Unit) {
        for (i in 0 until length()) optJSONObject(i)?.let(action)
    }

    private fun exportReport() {
        report.put("export_time", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(Date()))
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "hk9-gatt-${System.currentTimeMillis()}.json")
        }
        startActivityForResult(intent, exportRequest)
    }

    @Deprecated("Android activity result API is adequate here without an AndroidX dependency")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == exportRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(report.toString(2).toByteArray(Charsets.UTF_8)) }
                status.text = "JSON dosyası kaydedildi. Paylaşmadan önce cihaz kimlik bilgilerini kontrol et."
            } catch (e: Exception) { status.text = "Dosya yazma hatası: ${e.message}" }
        }
    }

    private fun closeGatt() {
        readQueue.clear(); pendingRead = null
        val old = gatt; gatt = null
        try { old?.disconnect(); old?.close() } catch (_: Exception) {}
    }
    override fun onDestroy() { stopScan(); closeGatt(); super.onDestroy() }
}
