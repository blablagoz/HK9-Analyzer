plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "tr.kavalci.hk9analyzer"
    compileSdk = 35
    defaultConfig { applicationId = "tr.kavalci.hk9analyzer"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
